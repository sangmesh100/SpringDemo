package com.sam;

public class Restaruant 
{
	public void greetCustomer()
	{
		System.out.println("welcome to restaruant...");
	}

}
