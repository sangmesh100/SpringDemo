package com.sam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");

		Restaruant restaruantObj1 = (Restaruant) context.getBean("restaruantBean");
		restaruantObj1.setWelcomeNote("Object1 is setting welcome note property");
		restaruantObj1.greetCustomer();

		Restaruant restaruantObj2 = (Restaruant) context.getBean("restaruantBean");
		restaruantObj2.greetCustomer();
	}

}


/*
O/p: when bean scope: prototype
Object1 is setting welcome note property
null
========================================
O/p: when bean scope: singleton
Object1 is setting welcome note property
Object1 is setting welcome note property

*/