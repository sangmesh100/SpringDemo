package com.sam;

public class Restaruant 
{
	IHotDrink hotDrink;
	
	/*Dependancy injection using constructor way*/
	
	public Restaruant(IHotDrink hotDrink) {
		super();
		this.hotDrink = hotDrink;
	}
	
	public void prepareHotDrink()
	{
		hotDrink.prepareHotDrink();
	}
	
}
