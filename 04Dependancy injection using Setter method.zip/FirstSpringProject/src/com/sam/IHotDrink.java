package com.sam;

public interface IHotDrink {
	public void prepareHotDrink();

}
