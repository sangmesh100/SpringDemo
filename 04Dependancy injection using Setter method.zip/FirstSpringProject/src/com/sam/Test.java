package com.sam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
		Restaruant restaruant = (Restaruant) context.getBean("restaruantBean");
		restaruant.prepareHotDrink();
	}

}
