package com.sam;

public class Restaruant 
{
	IHotDrink hotDrink;
	
	/*Dependancy injection using setter method way*/
	
	
	
	public void prepareHotDrink()
	{
		hotDrink.prepareHotDrink();
	}

	public IHotDrink getHotDrink() {
		return hotDrink;
	}

	public void setHotDrink(IHotDrink hotDrink) {
		this.hotDrink = hotDrink;
	}
	
}
