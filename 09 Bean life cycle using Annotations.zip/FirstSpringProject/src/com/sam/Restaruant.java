package com.sam;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Restaruant 
{
	public void greetCustomer()
	{
		System.out.println("Welcome to customer!");
	}
	
	@PostConstruct
	private void init() 
	{
		System.out.println("Restaruent Bean is going through init");	
	}
	
	@PreDestroy
	private void destroy() 
	{	
		System.out.println("Restaruent Bean is going through destroy");
	}
		
}
