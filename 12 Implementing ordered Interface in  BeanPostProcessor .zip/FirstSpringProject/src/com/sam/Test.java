package com.sam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) 
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");    
		
		((AbstractApplicationContext)context).registerShutdownHook();
		
		Restaruant restaruantObj = (Restaruant) context.getBean("restaruantBean");
		restaruantObj.greetCustomer();
	}
	
}
 
/*
OP:
	
	DemoBeanPostProcessor2 processing bean instance Before initilization(i.e after spring instantiates bean and before init lifecycle event) of : restaruantBean
	DemoBeanPostProcessor1 processing bean instance Before initilization(i.e after spring instantiates bean and before init lifecycle event) of : restaruantBean
	Bean is going through init 
	DemoBeanPostProcessor2 processing bean instance After initilization(just before init lifecycle event) of : restaruantBean
	DemoBeanPostProcessor1 processing bean instance After initilization(just before init lifecycle event) of : restaruantBean
	Welcome to customer!
	Bean will destoy now

	NOTE: WHICH ONE 1ST INITILIZATION ITS DEPEND ON SPRING FRAMEWORK USING ORDERED INTERFACE
	*/