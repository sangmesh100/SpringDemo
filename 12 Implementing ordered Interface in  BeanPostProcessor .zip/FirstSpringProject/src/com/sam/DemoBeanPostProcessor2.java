package com.sam;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;

public class DemoBeanPostProcessor2 implements BeanPostProcessor, Ordered {

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println(
				"DemoBeanPostProcessor2 processing bean instance After initilization(just before init lifecycle event) of : "
						+ beanName);
		return bean;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String  beanName) throws BeansException 	{
		System.out.println("DemoBeanPostProcessor2 processing bean instance Before initilization(i.e after spring instantiates bean and before init lifecycle event) of : "
						+ beanName);
		return bean;
	}

	@Override
	public int getOrder() {
		
		return 0;	// Zero means highest priority 
	}

}
