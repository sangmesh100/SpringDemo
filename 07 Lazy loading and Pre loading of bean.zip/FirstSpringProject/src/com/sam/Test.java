package com.sam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");   // default pre-loading

		Restaruant restaruantObj1 = (Restaruant) context.getBean("restaruantBean");		// before call the getBean()
		restaruantObj1.setWelcomeNote("Object1 is setting welcome note property");
		restaruantObj1.greetCustomer();

		Restaruant restaruantObj2 = (Restaruant) context.getBean("restaruantBean");
		restaruantObj2.greetCustomer();
	}

}

/*
 In case of BeanFactory interface using in spring framework. It is always perform lazy-loading
 									AND
 In case of ApplicationContext interface using in spring framework. It is always perform Pre-loading
 */