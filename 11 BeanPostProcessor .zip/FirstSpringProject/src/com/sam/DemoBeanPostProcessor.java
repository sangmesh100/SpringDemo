package com.sam;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class DemoBeanPostProcessor implements BeanPostProcessor 
{

	@Override
	public Object postProcessAfterInitialization(Object arg0, String arg1) throws BeansException 
	{
		System.out.println("processing bean instance After initilization(just before init lifecycle event) of : "+arg1);
		return arg0;
	}

	@Override
	public Object postProcessBeforeInitialization(Object arg0, String arg1) throws BeansException 
	{
		System.out.println("processing bean instance Before initilization(i.e after spring instantiates bean and before init lifecycle event) of : "+arg1);
		return arg0;
	}

}
