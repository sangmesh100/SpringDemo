package com.sam;


public class Restaruant 
{
	public void greetCustomer()
	{
		System.out.println("Welcome to customer!");
	}
	
	public void init()
	{
		System.out.println("Bean is going through init ");
	}
	public void destroy()
	{
		System.out.println("Bean will destoy now");
	}
}
