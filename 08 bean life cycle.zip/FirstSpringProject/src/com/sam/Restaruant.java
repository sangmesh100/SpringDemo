package com.sam;

 
public class Restaruant 
{
	public void greetCustomer()
	{
		System.out.println("Welcome to customer!");
	}
	
	private void init() 
	{
		System.out.println("Restaruent Bean is going through init");	
	}
	
	private void destroy() 
	{	
		System.out.println("Restaruent Bean is going through destroy");
	}
		
}
