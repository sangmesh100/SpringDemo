package com.sam;

import java.util.List;

public class Restaruant 
{
	private List restaruantWaiterList;

	
	public void setRestaruantWaiterList(List restaruantWaiterList) {
		this.restaruantWaiterList = restaruantWaiterList;
	}


	public void dispalyWaiterName()
	{
		System.out.println("All waiters working in Restaruant :" + restaruantWaiterList);
	}
		
}
